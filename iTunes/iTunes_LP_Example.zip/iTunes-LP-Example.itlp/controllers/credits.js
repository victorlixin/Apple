
var creditsController = new TKController({
  id: 'credits',
  backButton: '.home',
  scrollableElement : '.credits-content'
});
