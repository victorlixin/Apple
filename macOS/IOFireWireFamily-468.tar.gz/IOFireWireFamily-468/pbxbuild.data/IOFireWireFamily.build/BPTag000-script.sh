#!/bin/sh
script="${SYSTEM_DEVELOPER_DIR}/ProjectBuilder Extras/Kernel Extension Support/KEXTPreprocess";
if [ -x "$script" ]; then
    . "$script"
fi
