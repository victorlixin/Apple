/*
 *  IOFWBufferFillIsochPort.h
 *  IOFireWireFamily
 *
 *  Created by Niels on Mon Sep 09 2002.
 *  Copyright (c) 2002 Apple Computer, Inc. All rights reserved.
 *
 * $Log: not supported by cvs2svn $
 *
 */

// Deprecated