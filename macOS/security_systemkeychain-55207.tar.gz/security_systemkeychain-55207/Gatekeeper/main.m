//
//  main.m
//  Gatekeeper
//
//  Created by Love Hörnquist Åstrand on 2012-03-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
