/* $Header: /p/tcsh/cvsroot/tcsh/patchlevel.h,v 3.180 2012/02/13 16:33:50 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 18
#define PATCHLEVEL 1
#define DATE "2012-02-14"

#endif /* _h_patchlevel */
