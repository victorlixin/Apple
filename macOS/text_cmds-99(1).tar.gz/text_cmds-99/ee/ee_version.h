/*
 |	provide a version number for ee
 */

#define EE_VERSION "1.5.2"
#define DATE_STRING "$Date: 2010/06/04 02:35:35 $"
