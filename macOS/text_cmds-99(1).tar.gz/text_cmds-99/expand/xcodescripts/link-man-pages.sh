set -e -x
ln -f "$DSTROOT"/usr/share/man/man1/expand.1 \
	"$DSTROOT"/usr/share/man/man1/unexpand.1
