
#ifndef LocalOnlyTimeoutTests_h
#define LocalOnlyTimeoutTests_h

#include "unittest.h"

int LocalOnlyTimeoutTests(void);

#endif /* LocalOnlyTimeoutTests_h */
