
#ifndef InterfaceTest_h
#define InterfaceTest_h

#include "unittest.h"

int InterfaceTest(void);

#endif /* InterfaceTest_h */
