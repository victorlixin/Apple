
#ifndef mDNSCoreReceiveTest_h
#define mDNSCoreReceiveTest_h

#include "unittest.h"

int mDNSCoreReceiveTest(void);

#endif /* mDNSCoreReceiveTest_h */
