/*cc -o /tmp/dp dp.c -framework IOKit -framework ApplicationServices -Wall -g
*/

