/*
    File:       CBuffer.c

    Contains:   Implementation of the CBuffer abstract class


*/

#include "CBuffer.h"


#define super OSObject

    OSDefineMetaClassAndAbstractStructors(CBuffer, OSObject);
    

