#import <Cocoa/Cocoa.h>

@interface IrDAActions : NSObject
{
}
- (IBAction)StartIrDA:(id)sender;
- (IBAction)StopIrDA:(id)sender;
@end
