========================================================================
       DYNAMIC LINK LIBRARY : saslKERBEROSV4
========================================================================

-- No precompiled headers
-- Added c:\local\include [ path to kclient includes ]
-- Added c:\local\lib [ path to kclient libs ]
-- Added krbv4w32.lib
-- Added ws2_32.lib


*** WARNING:  Must actually point to the appropriate kerberos directories.
