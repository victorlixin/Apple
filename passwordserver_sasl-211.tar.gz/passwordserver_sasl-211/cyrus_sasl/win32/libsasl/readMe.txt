========================================================================
       DYNAMIC LINK LIBRARY : libsasl
========================================================================

This DLL represents CMU libsasl.

-----

Modifications made to project settings:

* Include path 
- Added main sasl include directory

* Precompiled header
- Turned off.
