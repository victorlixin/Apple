Project changes:

-- Include path
-- added ws2_32.lib
-- added libsasl.lib, path to debug dir
