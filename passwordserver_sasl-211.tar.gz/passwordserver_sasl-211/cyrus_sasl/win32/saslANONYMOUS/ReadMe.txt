========================================================================
       DYNAMIC LINK LIBRARY : saslANONYMOUS
========================================================================

SASL Authentication Module: ANONYMOUS

Modifications made to project settings:

* Include path 
- Added main sasl include directory

* Precompiled header
- Turned off.

* Libraries for linking
- Added winsock2 (ws2_32.lib)
