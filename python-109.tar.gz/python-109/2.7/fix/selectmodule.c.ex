g/\<NOTE_/s//(int)&/
wq
