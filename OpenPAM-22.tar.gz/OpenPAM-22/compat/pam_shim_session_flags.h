xlate(PAM_SILENT, 0x8000U, PAM_SILENT, 0x7fffffff - 1) 
