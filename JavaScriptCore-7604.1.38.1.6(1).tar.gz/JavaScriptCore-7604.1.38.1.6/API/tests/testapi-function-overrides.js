// testapi function overrides for testing.
override %%%{ /* Original f1 */ }%%%
with %%%{ /* Overridden f1 */ }%%%

override #$%{
    // Original f2
}#$%
with $$${ /* Overridden f2 */ }$$$

override %%%{ /* Original f3 */ }%%%
with %%%{ /* Overridden f3 */ }%%%

override %%%{
/* Original f4 */
}%%%
with %%%{ /* Overridden f4 */ }%%%
