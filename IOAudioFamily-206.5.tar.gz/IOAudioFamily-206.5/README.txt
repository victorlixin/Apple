Audio Engineering - Audio SW 0056/7103
----------------------------------------------------
IOAudioFamily Git Repository
Repository created: 07/16/12

Project owner: Matt Mora
Email: mxmora@apple.com
Phone: 974-3512

Copyright ©2012 Apple, Inc.  All Rights Reserved

----------------------------------------------------
About IOAudioFamily
----------------------------------------------------