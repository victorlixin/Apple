# MacRuby TODO: This file is a workaround to the load path not adding up with
# the layout of the ext files in the source root.
require File.dirname(__FILE__) + '/sha1/sha1'