
void Init_Continuation_body(void);

void
Init_continuation(void)
{
    Init_Continuation_body();
}
