require 'mkmf'
create_makefile('fcntl')
