/* This header exists for CRuby compatibility. */
