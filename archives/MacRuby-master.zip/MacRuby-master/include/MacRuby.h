/*
 * This file is covered by the Ruby license. See COPYING for more details.
 *
 * Copyright (C) 2012, The MacRuby Team. All rights reserved.
 * Copyright (C) 2007-2010, Apple Inc. All rights reserved
 */

#if __OBJC__
# include <Foundation/Foundation.h>
#endif

#define RUBY_INCLUDED_AS_FRAMEWORK 1
#include "ruby/ruby.h"
