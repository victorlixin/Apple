/*
 *  main.c
 *  corecrypto
 *
 *  Created on 09/13/2012
 *
 *  Copyright (c) 2012,2014,2015 Apple Inc. All rights reserved.
 *
 */
#include "testenv.h"
#include <stdio.h>

int main (int argc, char * const *argv) {
    int rc = tests_begin(argc, argv);
    return rc;
}
