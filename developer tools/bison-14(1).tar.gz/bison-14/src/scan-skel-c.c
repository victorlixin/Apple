#include <config.h>
#include "scan-skel.c"
