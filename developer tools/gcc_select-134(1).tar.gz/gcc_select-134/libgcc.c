// ICC insists on linking with libgcc.a, so build a placeholder library
// to let it link successfully.
int ___placeholder_library_for_ICC = 0;
