/*! @header foo.h
    @availability 10.2 and later
    @discussion foo discussion
    @cfbundleidentifier com.mycompany.mybundle
 */

/*! @function bar 
    @availability 10.3 and later
    @updated 2003-07-22
 */
void bar(int a);

