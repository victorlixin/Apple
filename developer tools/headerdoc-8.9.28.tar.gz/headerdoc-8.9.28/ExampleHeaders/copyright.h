/*! @header copytest
    @copyright Apple Computer
 */

/*! @function copyfunc
  This is a pointless function
 */

int copyfunc(int a);

