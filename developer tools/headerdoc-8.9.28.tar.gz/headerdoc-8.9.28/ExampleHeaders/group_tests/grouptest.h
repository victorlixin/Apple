/*! @header
    This is a really, really awesome header.  I'm not sure why.
    @indexgroup header group
 */

/*! Foo is not in a group. */
int foo;

/*! @group first group
    This is the documentation for the first group.
 */

/*! Bar is in first group. */
int bar;

/*! @group second group
    This is the documentation for the second group.
*/

/*! Baz is in second group.
    @indexgroup special group
 */
int baz;

/*! Joe is in second group.
    @indexgroup special group
 */
int joe;

