
/*! @class foo
    @discussion For more information, see <A HREF="{@docroot}/index.html">the index</A>, <A HREF="@docroot/index.html">the index</A>, or { @link foo The foo documentation }, or else maybe { @linkplain foo The plain foo docs }.  Thanks.
 */
class foo
{


}

