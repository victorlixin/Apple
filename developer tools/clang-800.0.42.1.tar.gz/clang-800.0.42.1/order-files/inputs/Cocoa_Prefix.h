// RUN: %clang -x objective-c-header %s
#include <Cocoa/Cocoa.h>
