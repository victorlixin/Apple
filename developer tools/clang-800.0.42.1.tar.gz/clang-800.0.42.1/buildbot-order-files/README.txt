This directory is designed to contain buildbot produced order files, but only
when integrated into the ``megaclang`` repository.

The ``megaclang`` merge config excludes this directory, and instead the
buildbots are expected to check in the order files they produce as part of their
Apple-style builds.
