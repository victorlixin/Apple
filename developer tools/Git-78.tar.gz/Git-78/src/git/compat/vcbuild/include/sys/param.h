/* Intentionally empty file to support building git with MSVC */
