
int git_SHA1_Update_Chunked(platform_SHA_CTX *c, const void *data, size_t len);
