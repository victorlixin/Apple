Credits
-------

The file icons were created by Marco <fatal@global.uibk.ac.at>

