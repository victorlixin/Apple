#include <AppKit/AppKit.h>

#define APP_NAME @"GNUstep"

/*
 * Initialise and go!
 */

int main(int argc, const char *argv[]) 
{
  return NSApplicationMain (argc, argv);
}
