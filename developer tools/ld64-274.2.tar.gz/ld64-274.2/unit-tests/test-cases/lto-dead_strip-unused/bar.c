

void bar() 
{
}


extern void unused1();

void unused2()
{
	unused1();
}


