
int foo = 5;