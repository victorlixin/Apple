#include <stdio.h>

int foo()
{
	fprintf(stdout, "hello foo\n");
	return 0;
}