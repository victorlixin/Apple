#include <stdio.h>

void a() {
}

void b() {
}

void c() {
}
