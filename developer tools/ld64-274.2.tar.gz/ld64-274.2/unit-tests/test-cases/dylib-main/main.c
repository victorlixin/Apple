#include <stdio.h>

int main()
{
	fprintf(stdout, "hello\n");
	return 0;
}