

void bar() {}

