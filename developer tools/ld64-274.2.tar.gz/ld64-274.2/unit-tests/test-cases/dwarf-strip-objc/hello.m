#include <Foundation/Foundation.h>


int main()
{
	[NSString stringWithUTF8String: "hello"];
	return 0;
}