
void foo2() {}
