
void bar2() {}
