#include <Foundation/Foundation.h>

@interface Foo : NSObject
@end


extern void foo2();

