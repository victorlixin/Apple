
extern int foo();
extern int bar();
extern int baz();

int main()
{
	foo();
	bar();
	baz();
	return 0;
}
