
int tent;

int foo() { return tent; }
