int bar3() { return 0; }

__attribute__((constructor))
void bar3_init() { }
