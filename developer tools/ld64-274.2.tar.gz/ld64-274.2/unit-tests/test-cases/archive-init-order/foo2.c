int foo2() { return 1; }

__attribute__((constructor))
void foo2_init() { }
