int foo2(void)
{
  return 0;
}
