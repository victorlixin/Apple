int bar;
int foo1()
{
	return bar;
}

