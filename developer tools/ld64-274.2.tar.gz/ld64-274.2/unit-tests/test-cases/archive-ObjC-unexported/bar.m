#include <Foundation/Foundation.h>

@interface Foobar : NSObject
@end

void other() 
{
	[[Foobar alloc] init];
}

void bar() 
{
}

