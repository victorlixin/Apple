
#include <Foundation/Foundation.h>

@interface Bar : NSObject
@end

@implementation Bar
@end

