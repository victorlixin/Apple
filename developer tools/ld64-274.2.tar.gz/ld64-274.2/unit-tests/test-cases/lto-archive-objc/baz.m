#include <Foundation/Foundation.h>

@interface NSObject(MyCategory)
- (void) doit;
@end

@implementation NSObject(MyCategory)
- (void) doit
{
}
@end
