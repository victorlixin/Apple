
#include "header.h"

void bar() { LOTS_O_PROBES }


