
int foo = 1;
int bar = 2;
int baz = 3;

