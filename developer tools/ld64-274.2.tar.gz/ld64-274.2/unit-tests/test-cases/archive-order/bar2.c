int bar2() { return 0; }
