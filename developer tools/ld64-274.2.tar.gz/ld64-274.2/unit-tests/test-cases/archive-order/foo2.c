int foo2() { return 1; }
