#include <stdio.h>
void foo() 
{
   fprintf(stderr, "hello\n");
}
