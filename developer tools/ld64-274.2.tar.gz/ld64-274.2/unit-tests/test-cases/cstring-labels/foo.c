
void func() {}

const char kFoo[] = "foo";

const char* kFoo2 = "hello";
