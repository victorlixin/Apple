
extern const char* mystring;

const char** myp = &mystring;
