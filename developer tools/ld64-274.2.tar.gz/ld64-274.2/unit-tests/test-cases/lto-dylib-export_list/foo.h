
class Foo {
public:
    static void doit() { } 
    static void doit2() { }
};
