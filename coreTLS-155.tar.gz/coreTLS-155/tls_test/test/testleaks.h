//
//  testleaks.h
//  coretls
//

#ifndef _TESTLEAKS_H_
#define _TESTLEAKS_H_ 1

int testleaks(void);

#endif /* _TESTLEAKS_H_ */
