//
//  darktool.h
//  PowerManagement
//
//  Created by Ethan Bold on 9/19/13.
//
//

#ifndef PowerManagement_darktool_h
#define PowerManagement_darktool_h

#endif
