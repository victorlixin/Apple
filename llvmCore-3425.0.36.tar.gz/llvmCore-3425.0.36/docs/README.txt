LLVM Documentation
==================

The LLVM documentation is currently written in two formats:

  * Plain HTML documentation.

  * reStructured Text documentation using the Sphinx documentation generator. It
    is currently tested with Sphinx 1.1.3.

    For more information, see the "Sphinx Introduction for LLVM Developers"
    document.
