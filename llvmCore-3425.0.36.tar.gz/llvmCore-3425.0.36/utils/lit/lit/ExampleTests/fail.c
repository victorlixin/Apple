// RUN: echo 'I am some stdout'
// RUN: false
